%相关性匹配是通过计算模板和图像的互相关函数来找到模板在图像中的最佳匹配位置，而FFT可以高效地计算互相关函数，因为互相关在频域中可以通过傅里叶变换、点乘和逆傅里叶变换来实现
%模板匹配的原理就是利用目标的边缘信息（高频内容）用于搜索目标图像的模板所在位置，然后将模板图像在输入图像上滑动匹配，找到最大匹配度


%读取原图和模板图像
original = imread('D:\fft_matching\smalljob\ImageSet\match.jpg');        %读取待匹配的原图像
template = imread('D:\fft_matching\smalljob\ImageSet\match_window.jpg'); %读取需要匹配的部分

%将图像从RGB颜色空间转换为灰度颜色空间（这里我们只保留“亮度”，也叫灰度）
original_gray = im2gray(original);             %会自动把彩色图 → 黑白灰图（1个通道）
template_gray = im2gray(template);

%转为double精度并归一化至[0,1]
original_gray = im2double(original_gray);      %把像素值从 uint8 (0~255) → double (0~1)
template_gray = im2double(template_gray);

%获取尺寸
[o_height, o_width] = size(original_gray);     %原图像尺寸
[t_height, t_width] = size(template_gray);     %模板图像尺寸

%傅里叶变换
t_fft = fft2(template_gray, o_height, o_width);%补零至原图尺寸让两幅图像在频域中可相乘
o_fft = fft2(original_gray);                   %对原图进行二维FFT

%计算相关性（原理：频域中乘法 = 空域中的相关性计算）
R = o_fft .* conj(t_fft);                      %原图FFT与模板FFT共轭相乘，注意.*是逐元素乘法，不是矩阵乘法
R_normalized = R ./ (abs(R) + eps);            %幅度归一化，除以幅度（加极小值eps防止除零）

%逆傅里叶变换得到相关矩阵，取实数部分
c = ifft2(R_normalized);                       %相关性图，复数
c = real(c);                                   %若原始图像是纯实数，其傅里叶变换结果满足共轭对称性，则逆傅里叶变换后的结果理论上应仍为实数，但由于数值计算的舍入误差或中间处理步骤（如除以复数），实际结果可能包含微小虚部

%归一化到[0, 1]范围，线性归一化后：最低点是0，最高点是1，之后能清楚地看到哪里最像（数值 = 1），
c = (c - min(c(:))) / (max(c(:)) - min(c(:))); 

%找到最大值的位置
[~, max_idx] = max(c(:));                      %找到最大值的线性索引
[y, x] = ind2sub(size(c), max_idx);            %转换为行列坐标

%定义显示的矩形
rect_pos = [x, y, t_width, t_height];          % x左上角的列索引（X坐标），y左上角的行索引（Y坐标）

%绘制通过相关图像最大值的水平灰度剖面图
figure;                                        %创建一个新图形窗口
profile_line = c(y, :);                        %提取相关矩阵c中第y行的所有列值，形成水平灰度剖面线的数据
plot(profile_line);                            %在当前图形窗口绘制
hold on;                                       %保持当前图形窗口的内容，允许在同一窗口继续绘制其他内容
plot(x, profile_line(x), 'ro');                %标记最大值点，用红色圆圈ro标记
xlabel('水平轴');
ylabel('灰度值');
title('水平灰度剖面图及最大值位置');

%标记矩形框显示匹配区域
figure;
imshow(original);
hold on;
rectangle('Position', rect_pos, 'EdgeColor', 'g', 'LineWidth', 2);
title('fft匹配图');
hold off;                                      %hold on 和 hold off 用于同时显示多个元素（图+框）

